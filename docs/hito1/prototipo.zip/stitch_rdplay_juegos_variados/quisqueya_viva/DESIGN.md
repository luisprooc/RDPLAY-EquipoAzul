# Design System Strategy: Tropical Kineticism

## 1. Overview & Creative North Star: "The Digital Carnaval"
This design system moves away from the static, rigid grids of traditional educational apps to embrace **Tropical Kineticism**. The goal is to capture the rhythmic, high-energy soul of the Dominican Republic through a "Digital Carnaval" lens.

Instead of a standard boxy layout, we utilize **intentional asymmetry** and **organic layering**. We break the "template" look by allowing cultural elements—like a stylized Güira pattern or a 3D-rendered mango—to break container boundaries. The interface should feel like a living, breathing celebration: vibrant but sophisticated, playful but premium. We prioritize "breathing room" (white space) to let the high-energy colors pop without overwhelming the learner.

## 2. Color: Vibe over Volume
The palette is a sophisticated evolution of the Dominican flag. We don't just use Red, Blue, and White; we use their cinematic variants to create depth.

*   **Primary (`#ba001e`):** Our "Power Red." Used for momentum-driving actions.
*   **Secondary (`#3b5b92`):** Our "Atlantic Deep Blue." Provides the grounding, trustworthy base for navigation.
*   **Tertiary (`#765600` / `#ffbf00`):** Our "Amber Sun." These accents bring the tropical warmth, used for rewards and highlights.

### The "No-Line" Rule
**Borders are strictly prohibited for sectioning.** To separate a profile card from a background, do not use a 1px line. Instead, use a background shift—place a `surface-container-lowest` card against a `surface` background. Let the tonal change define the edge.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, physical layers. 
*   **Level 0:** `surface` (The base "canvas").
*   **Level 1:** `surface-container-low` (Secondary content zones).
*   **Level 2:** `surface-container-highest` (Interactive cards or focal points).
This nesting creates a natural, soft depth that feels premium and tactile.

### The "Glass & Gradient" Rule
To add "soul," avoid flat `primary` fills on large heroes. Use a linear gradient transitioning from `primary` to `primary-container`. For floating navigation or modals, employ **Glassmorphism**: use a semi-transparent `surface` with a `20px` backdrop-blur. This ensures the vibrant Dominican colors bleed through the UI, making it feel integrated with the environment.

## 3. Typography: Friendly Authority
We use a dual-font system to balance playfulness with legibility.

*   **Display & Headlines (Plus Jakarta Sans):** A modern, geometric sans-serif with a friendly apertures. Use `display-lg` (3.5rem) for big "Victory" moments and `headline-md` (1.75rem) for module titles. The wide stance of Jakarta Sans conveys a "Modern Caribbean" confidence.
*   **Body & Titles (Be Vietnam Pro):** This is our workhorse. It is highly legible at small scales (`body-sm` 0.75rem). The slightly taller x-height makes it perfect for long-form educational content, ensuring "all ages" can read it without strain.

**Editorial Rule:** Use extreme scale contrast. Pair a `display-sm` headline with a `body-md` description to create an "Editorial Magazine" feel.

## 4. Elevation & Depth: Tonal Layering
We move beyond the "Material 2" shadow era. Depth is now atmospheric.

*   **The Layering Principle:** Place a `surface-container-lowest` card (brightest) on a `surface-container-low` background. The shift in brightness creates "Lift" without a single drop shadow.
*   **Ambient Shadows:** If an element must float (like a "Play Now" button), use a shadow tinted with the `on-surface` color at 6% opacity. Set blur values to `24px` or higher. It shouldn't look like a shadow; it should look like a soft glow.
*   **The "Ghost Border" Fallback:** For high-density data, use the `outline-variant` token at **15% opacity**. It provides a "suggestion" of a boundary without closing off the layout.

## 5. Components: Tactile & Cultural

### Buttons
*   **Primary:** `primary` background with `on-primary` text. Use `xl` (3rem) rounded corners. Add a subtle `primary-container` inner glow on the top edge to make it look "pressable."
*   **Secondary:** Glassmorphic fill. `surface` at 40% opacity with a backdrop-blur.

### Cards & Lists
*   **The Divider Ban:** Never use horizontal lines. Use `1.5rem` (md) vertical spacing to separate list items. 
*   **Cultural Texture:** Every 3rd card should feature a subtle, low-contrast SVG pattern (e.g., a repeating Tambora drum or Palm leaf) in the background using `surface-variant` at 5% opacity.

### Inputs & Selection
*   **Checkboxes/Radios:** Use `full` (9999px) rounding. When "Checked," the component should scale up by 10% momentarily—a "pop" of energy.
*   **Input Fields:** Use `surface-container-highest`. No borders. The label should be `label-md` in `secondary` blue to maintain a "Cultural Professionalism."

### Custom Component: The "Achievement Totem"
Instead of a standard badge, use an overlapping stack of `tertiary` (Amber) circles with icon symbols (Catedral Primada, Mango, Maraca). This creates a unique visual signature specific to this design system.

## 6. Do's and Don'ts

### Do
*   **Do** allow illustrations to overlap container edges to create 3D depth.
*   **Do** use `lg` (2rem) and `xl` (3rem) corner radii for a friendly, approachable feel.
*   **Do** use "Plus Jakarta Sans" for all numeric data—it looks more celebratory.

### Don't
*   **Don't** use pure black `#000000` for text. Use `on-surface` (`#2c2f30`) to keep the "vibrant" vibe from feeling "harsh."
*   **Don't** use 100% opaque borders. They act as "visual cages" that kill the energy of the tropical palette.
*   **Don't** use "Standard" easing. Use a "Back-Out" transition (slight overshoot) for all button hovers and modal entries to mimic the bounce of Dominican music.